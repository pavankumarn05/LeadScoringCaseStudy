from fastapi import FastAPI
from app.api.routes import router
from app.core.config import config

app = FastAPI(title=config.APP_NAME, version=config.VERSION)
app.include_router(router)