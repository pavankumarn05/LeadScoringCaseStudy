class Config:
    APP_NAME = "FastAPI Demo"
    VERSION = "1.0.0"

config = Config()